# Wireframe-22
Projects and assets from Wireframe #22

Source Code: Create a Scramble-style scrolling landscape, pages 40-41, by Mark Vanstone

The code example is licenced under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported.
