https://creativecommons.org/licenses/by-nc-sa/3.0/legalcode
